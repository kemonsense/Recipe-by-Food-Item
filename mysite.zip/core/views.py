# Create your views here.
from django.shortcuts import render
import requests

def home(request):
    response = requests.get('http://ip-api.com/json')
    geodata = response.json()
    return render(request, 'core/home.html', {
        'ip': geodata['query'],
        'country': geodata['country'],
        'countryCode':geodata['countryCode'],
        'region':geodata['region'],
        "regionName":geodata['regionName'],
        "city":geodata['city'],
        "zip":geodata['zip'],
        "lat":geodata['lat'],
        "lon":geodata['lon'],
        "timezone":geodata['timezone'],
        "isp":geodata['isp'],
        "as":geodata['as'],
    })